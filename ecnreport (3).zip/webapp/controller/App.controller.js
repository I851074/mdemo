/**
 * App View Controller
 *
 * This is the view controller for the App view. This is the view inside which the rest of the views are loaded.
 *
 * @author Kush Patel.
 *
 * Date         Version     Modified By     Description
 * Mar 25 2019   1.0         PATELK          Initial Version
 */
sap.ui.define([
	"com/merck/ipi/ecnreport/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/merck/ipi/ecnreport/util/utilities",
	"sap/m/MessageBox"
], function (BaseController, JSONModel, utilities, MessageBox) {
	"use strict";

	return BaseController.extend("com.merck.ipi.ecnreport.controller.App", {
		onInit: function () {
			// initialize shared view model
			var sharedViewModel = new JSONModel({
				appBusy: false
			});
			sharedViewModel.setDefaultBindingMode("OneWay");
			this.getOwnerComponent().setModel(sharedViewModel, "sharedViewModel");
			// ZGSPC_ECN_REP_SRV
			// initialize s/4 models
		},

		handleMetadataFailure: function (mArgs) {
			jQuery.sap.log.error(mArgs.getParameter("message"), ["Status Code: " + mArgs.getParameter("statusCode"),
				"Status Text: " + mArgs.getParameter("statusText"),
				"Component:" + this.getOwnerComponent()
			]);

			sap.m.MessageBox.error(this.getResourceBundle().getText("message.failure.ConnectionError"), {
				title: this.getResourceBundle().getText("message.failure.ConnectionErrorTitle"),
				icon: sap.m.MessageBox.Icon.ERROR,
				actions: [sap.m.MessageBox.Action.OK],
				details: mArgs.getParameter("message") + ". Status Code: " + mArgs.getParameter(
					"statusCode") + ". Status Text: " + mArgs.getParameter("statusText"),
				onClose: function () {
					utilities.exitApp();
				}
			});
		}
	});
});