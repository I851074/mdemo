/**
 * Base View Controller
 * 
 * This is the view controller for the Base view. All view controllers extend
 * this controller.
 *
 * @author Kush Patel.
 * 
 * Date         Version     Modified By     Description
 * Mar 25 2019   1.0         PATELK          Initial Version
 */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, History, MessageBox, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("com.merck.ipi.ecnreport.controller.BaseController", {
		_iServiceCounter: 0, // the service counter
		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return this.getOwnerComponent().getRouter();
		},

		/**
		 * Utility method to keep track of service completion
		 * @param {sap.ui.core.Control} oControl the control to be attached
		 * @public
		 */
		serviceCalled: function () {
			if (this._iServiceCounter === 0) {
				this.showSpinner();
			}
			this._iServiceCounter++;
		},

		/**
		 * Utility method to keep track of service completion
		 * @param {sap.ui.core.Control} oControl the control to be attached
		 * @public
		 */
		serviceCompleted: function () {
			this._iServiceCounter--;
			if (this._iServiceCounter === 0) {
				this.hideSpinner();
			}
		},

		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/**
		 * Event handler  for navigating back.
		 * It checks if there is a history entry. If yes, history.go(-1) will happen.
		 * If not, it will replace the current entry of the browser history with the master route.
		 * @public
		 */
		onNavBack: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("objectList", true);
			}
		},

		/**
		 * Utility method to show a spinner
		 * @param {sap.ui.core.Control} oControl the control to be attached
		 * @public
		 */
		showSpinner: function () {
			var sharedViewModel = this.getOwnerComponent().getModel("sharedViewModel");
			sharedViewModel.setProperty("/appBusy", true);
		},

		/**
		 * Utility method to hide the spinner
		 * @param {sap.ui.core.Control} oControl the control to be attached
		 * @public
		 */
		hideSpinner: function () {
			var sharedViewModel = this.getOwnerComponent().getModel("sharedViewModel");
			sharedViewModel.setProperty("/appBusy", false);
		},

		/**
		 * Utility method to generate a GUID
		 * @param {sap.ui.core.Control} oControl the control to be attached
		 * @public
		 */
		generateUUID: function () {
			var d = new Date().getTime();
			var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
				var r = (d + Math.random() * 16) % 16 | 0;
				d = Math.floor(d / 16);
				return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
			});
			return uuid;
		},

		/**
		 * Utility method to attach a control, typically a dialog,
		 * to the view, and syncing the styleclass of the application
		 * @param {sap.ui.core.Control} oControl the control to be attached
		 * @public
		 */
		attachControl: function (oControl) {
			var sCompactCozyClass = this.getOwnerComponent().getContentDensityClass();
			jQuery.sap.syncStyleClass(sCompactCozyClass, this.getView(), oControl);
			this.getView().addDependent(oControl);
		},
		treatAsUTC: function (date) {
			var result = new Date(date);
			result.setMinutes(result.getMinutes() - result.getTimezoneOffset());
			return result;
		}
	});
});