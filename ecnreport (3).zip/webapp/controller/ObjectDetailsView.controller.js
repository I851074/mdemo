/**
 * Specification Change Report Details Controller
 *
 * This is the view controller for the Object Details view. This is the view that displays
 * the details of a specification change report.
 *
 * @author Kush Patel.
 *
 * Date         Version     Modified By     Description
 * Mar 25, 2019   1.0         PATELK          Initial Version
 */
sap.ui.define([
	"com/merck/ipi/ecnreport/controller/BaseController",
	"com/merck/ipi/ecnreport/model/formatter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, formatter, JSONModel, Sorter, Filter, FilterOperator) {
	"use strict";
	return BaseController.extend("com.merck.ipi.ecnreport.controller.ObjectDetailsView", {
		formatter: formatter, // the formatter
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.merck.ipi.ecnreport.view.ObjectDetailsView
		 */
		onInit: function () {
			// set context density
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());

			// Get Context Path for details screen
			var oRouter = this.getRouter();
			oRouter.getRoute("objectDetails").attachMatched(this._onRouteMatched, this);
		},

		/**
		 * This method is called upon desctuction of the View. The controller should perform its internal 
		 * destruction in this hook. It is only called once per View instance, unlike the onBeforeRendering 
		 * and onAfterRendering hooks. (Even though this method is declared as "abstract", it does not need 
		 * to be defined in controllers, if the method does not exist, it will simply not be called.)
		 */
		onExit: function () {},

		/**
		 * Route matched, get screen relavant details from parameters passed
		 * @param oEvent
		 */
		_onRouteMatched: function (oEvent) {
			this.showSpinner();
			var oArgs = oEvent.getParameter("arguments");

			var selectedObject = this.getOwnerComponent().getModel("sharedViewModel").getProperty("/selectedObject");
			// Check if selected object is stored
			if (!selectedObject) {
				this.getOwnerComponent().getModel("s4ReportModel").read(
					"/ZGSPC_C_ECNREPORT", {
						filters: [
							new Filter("Specification", FilterOperator.EQ, oArgs.Specification),
							new Filter("ECN", FilterOperator.EQ, oArgs.ECN)
						],
						success: function (data) {
							this.getOwnerComponent().getModel("s4ReportHeaderModel").setData(data.results[0]);
							this.hideSpinner();
						}.bind(this),
						error: function (error) {
							jQuery.sap.log.error("ERROR: " + JSON.stringify(error));
							//reject(error);
							this.hideSpinner();
						}.bind(this)
					}
				);
			} else {
				this.getOwnerComponent().getModel("s4ReportHeaderModel").setData(selectedObject);
				this.hideSpinner();
			}
			//Update table binding with selected object details
			this.getView().byId("detailtable").bindItems({
				path: "s4ReportDetailModel>/ZGSPC_C_ECN_DET",
				sorter: [
					new Sorter("PropertyGroup", false),
					new Sorter("Property", false),
					new Sorter("Characteristic", false)],
				template: this.getView().byId("detailtable").getBindingInfo("items").template,
				filters: [
					new Filter("Specification", sap.ui.model.FilterOperator.EQ, oArgs.Specification),
					new Filter("ECN", sap.ui.model.FilterOperator.EQ, oArgs.ECN)
				]
			});
		}
	});
});