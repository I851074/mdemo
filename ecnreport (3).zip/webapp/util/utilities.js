sap.ui.define([
	"sap/ui/Device",
	"sap/ui/core/format/DateFormat"
], function(Device, DateFormat) {
	"use strict";

return {
		exitApp: function() {
			// navigate to flp
			var oHistory = sap.ui.core.routing.History.getInstance(),
				sPreviousHash = oHistory.getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#"
					}
				});
			}
		}
	};
});